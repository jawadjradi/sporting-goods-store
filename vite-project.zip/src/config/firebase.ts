import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDaoMftrXKlEgI2iNG6f6_hA67hEoDUMAA",
  authDomain: "sporting-goods-30f8b.firebaseapp.com",
  projectId: "sporting-goods-30f8b",
  storageBucket: "sporting-goods-30f8b.firebasestorage.app",
  messagingSenderId: "793307101380",
  appId: "1:793307101380:web:2e8c97fb9f39c1fd61b191",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();
export default app;

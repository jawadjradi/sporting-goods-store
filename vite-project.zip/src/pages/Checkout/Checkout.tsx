import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { CreditCard, MapPin } from "lucide-react";
import { collection, addDoc, serverTimestamp, doc, updateDoc, increment } from "firebase/firestore";
import { db } from "../../config/firebase";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";
import "./Checkout.css";

export default function CheckoutPage() {
  const { currentUser } = useAuth();
  const { items, total, clearCart } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    street: "",
    city: "",
    state: "",
    zip: "",
    country: "United States",
  });

  function updateForm(field: string, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleCheckout(e: React.FormEvent) {
    e.preventDefault();
    if (!currentUser || items.length === 0) return;

    setLoading(true);
    try {
      const orderItems = items.map((item) => ({
        productId: item.productId,
        productName: item.product.name,
        productImage: item.product.images?.[0] || "",
        price: item.product.price,
        quantity: item.quantity,
      }));

      const shipping = total >= 100 ? 0 : 9.99;

      // Create order
      const orderRef = await addDoc(collection(db, "orders"), {
        userId: currentUser.uid,
        items: orderItems,
        total: total + shipping,
        status: "pending",
        shippingAddress: form,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Reduce stock & log inventory
      for (const item of items) {
        const productRef = doc(db, "products", item.productId);
        await updateDoc(productRef, { stock: increment(-item.quantity) });
        await addDoc(collection(db, "inventoryLogs"), {
          productId: item.productId,
          type: "sale",
          quantity: -item.quantity,
          note: `Order ${orderRef.id}`,
          createdAt: serverTimestamp(),
        });
      }

      clearCart();
      navigate(`/orders?success=${orderRef.id}`);
    } catch (err) {
      console.error("Checkout error:", err);
    }
    setLoading(false);
  }

  if (items.length === 0) {
    navigate("/cart");
    return null;
  }

  return (
    <div className="page-wrapper">
      <div className="container">
        <motion.h1
          className="checkout-title"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <span className="glow-text">Checkout</span>
        </motion.h1>

        <form className="checkout-layout" onSubmit={handleCheckout}>
          <motion.div
            className="checkout-form-section"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="checkout-card">
              <div className="checkout-card-header">
                <MapPin size={20} />
                <h3>Shipping Address</h3>
              </div>
              <div className="form-grid">
                <div className="input-group" style={{ gridColumn: "1 / -1" }}>
                  <label>Full Name</label>
                  <input
                    className="input-field"
                    value={form.fullName}
                    onChange={(e) => updateForm("fullName", e.target.value)}
                    required
                  />
                </div>
                <div className="input-group" style={{ gridColumn: "1 / -1" }}>
                  <label>Street Address</label>
                  <input
                    className="input-field"
                    value={form.street}
                    onChange={(e) => updateForm("street", e.target.value)}
                    required
                  />
                </div>
                <div className="input-group">
                  <label>City</label>
                  <input
                    className="input-field"
                    value={form.city}
                    onChange={(e) => updateForm("city", e.target.value)}
                    required
                  />
                </div>
                <div className="input-group">
                  <label>State</label>
                  <input
                    className="input-field"
                    value={form.state}
                    onChange={(e) => updateForm("state", e.target.value)}
                    required
                  />
                </div>
                <div className="input-group">
                  <label>ZIP Code</label>
                  <input
                    className="input-field"
                    value={form.zip}
                    onChange={(e) => updateForm("zip", e.target.value)}
                    required
                  />
                </div>
                <div className="input-group">
                  <label>Country</label>
                  <input
                    className="input-field"
                    value={form.country}
                    onChange={(e) => updateForm("country", e.target.value)}
                    required
                  />
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            className="checkout-summary"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="summary-card">
              <h3>Order Summary</h3>
              <div className="checkout-items">
                {items.map((item) => (
                  <div key={item.productId} className="checkout-item">
                    <div className="checkout-item-image">
                      {item.product.images?.[0] ? (
                        <img src={item.product.images[0]} alt="" />
                      ) : (
                        <span>📦</span>
                      )}
                    </div>
                    <div className="checkout-item-info">
                      <div>{item.product.name}</div>
                      <div style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>
                        Qty: {item.quantity}
                      </div>
                    </div>
                    <div className="checkout-item-price">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
              <div className="summary-divider" />
              <div className="summary-row">
                <span>Subtotal</span>
                <span>${total.toFixed(2)}</span>
              </div>
              <div className="summary-row">
                <span>Shipping</span>
                <span>{total >= 100 ? "Free" : "$9.99"}</span>
              </div>
              <div className="summary-divider" />
              <div className="summary-row total">
                <span>Total</span>
                <span>${(total + (total >= 100 ? 0 : 9.99)).toFixed(2)}</span>
              </div>
              <button
                className="btn btn-primary btn-lg"
                type="submit"
                disabled={loading}
                style={{ width: "100%", marginTop: 20 }}
              >
                {loading ? "Processing..." : (
                  <><CreditCard size={18} /> Place Order</>
                )}
              </button>
            </div>
          </motion.div>
        </form>
      </div>
    </div>
  );
}

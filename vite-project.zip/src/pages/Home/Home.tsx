import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Zap, Shield, Truck, Star } from "lucide-react";
import { useEffect, useState } from "react";
import { collection, getDocs, query, where, limit } from "firebase/firestore";
import { db } from "../../config/firebase";
import type { Product } from "../../types";
import { useCart } from "../../context/CartContext";
import { ShoppingCart } from "lucide-react";
import HeroBackground from "../../components/HeroBackground/HeroBackground";
import "./Home.css";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.6, ease: [0.4, 0, 0.2, 1] as [number, number, number, number] },
  }),
};

const sports = [
  { icon: "🏃", name: "Running", slug: "running" },
  { icon: "🏀", name: "Basketball", slug: "basketball" },
  { icon: "⚽", name: "Football", slug: "football" },
  { icon: "🎾", name: "Tennis", slug: "tennis" },
  { icon: "🏊", name: "Swimming", slug: "swimming" },
  { icon: "🏋️", name: "Training", slug: "training" },
];

export default function Home() {
  const [featured, setFeatured] = useState<Product[]>([]);
  const { addItem } = useCart();

  useEffect(() => {
    async function fetchFeatured() {
      try {
        const q = query(collection(db, "products"), where("featured", "==", true), limit(8));
        const snap = await getDocs(q);
        const products = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Product));
        setFeatured(products);
      } catch {
        // Firestore may be empty initially
      }
    }
    fetchFeatured();
  }, []);

  return (
    <div style={{ position: "relative", zIndex: 1 }}>
      {/* Hero */}
      <section className="home-hero">
        <HeroBackground />
        <div className="hero-glow hero-glow-1" />
        <div className="hero-glow hero-glow-2" />

        <motion.div
          className="hero-content"
          initial="hidden"
          animate="visible"
        >
          <motion.div className="hero-badge" variants={fadeUp} custom={0}>
            <Zap size={14} /> Next-Gen Athletic Gear
          </motion.div>

          <motion.h1 className="hero-title" variants={fadeUp} custom={1}>
            Elevate Your <br />
            <span className="highlight">Game Beyond</span> <br />
            Limits
          </motion.h1>

          <motion.p className="hero-subtitle" variants={fadeUp} custom={2}>
            Premium sporting goods engineered for peak performance. 
            Experience the future of athletic excellence.
          </motion.p>

          <motion.div className="hero-actions" variants={fadeUp} custom={3}>
            <Link to="/products" className="btn btn-primary btn-lg">
              Shop Now <ArrowRight size={18} />
            </Link>
            <Link to="/products?featured=true" className="btn btn-secondary btn-lg">
              Featured Gear
            </Link>
          </motion.div>

          <motion.div className="hero-stats" variants={fadeUp} custom={4}>
            <div className="hero-stat">
              <div className="hero-stat-value">500+</div>
              <div className="hero-stat-label">Products</div>
            </div>
            <div className="hero-stat">
              <div className="hero-stat-value">50K+</div>
              <div className="hero-stat-label">Athletes</div>
            </div>
            <div className="hero-stat">
              <div className="hero-stat-value">99%</div>
              <div className="hero-stat-label">Satisfaction</div>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Categories */}
      <section className="categories-section container">
        <div className="section-header">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Shop by <span className="glow-text">Sport</span>
          </motion.h2>
          <p>Find the perfect gear for your discipline</p>
        </div>

        <div className="categories-grid">
          {sports.map((sport, i) => (
            <motion.div
              key={sport.slug}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
            >
              <Link to={`/products?sport=${sport.slug}`}>
                <div className="category-card">
                  <span className="category-icon">{sport.icon}</span>
                  <h3>{sport.name}</h3>
                  <div className="cat-glow" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      {featured.length > 0 && (
        <section className="featured-section container">
          <div className="section-header">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <span className="glow-text">Featured</span> Gear
            </motion.h2>
            <p>Hand-picked selections from our top collections</p>
          </div>

          <div className="products-grid">
            {featured.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
              >
                <Link to={`/products/${product.id}`}>
                  <div className="product-card">
                    <div className="product-card-image">
                      {product.images?.[0] ? (
                        <img src={product.images[0]} alt={product.name} />
                      ) : (
                        <div style={{ fontSize: "3rem", opacity: 0.3 }}>📦</div>
                      )}
                      {product.compareAtPrice && (
                        <span className="product-badge badge badge-danger">Sale</span>
                      )}
                      <button
                        className="quick-add"
                        onClick={(e) => {
                          e.preventDefault();
                          addItem(product);
                        }}
                      >
                        <ShoppingCart size={18} />
                      </button>
                    </div>
                    <div className="product-card-body">
                      <div className="product-card-brand">{product.brand}</div>
                      <div className="product-card-name">{product.name}</div>
                      <div className="product-card-price">
                        <span className="current">${product.price.toFixed(2)}</span>
                        {product.compareAtPrice && (
                          <span className="original">${product.compareAtPrice.toFixed(2)}</span>
                        )}
                      </div>
                      <div className="product-card-rating">
                        <span className="stars">
                          {"★".repeat(Math.round(product.rating || 0))}
                          {"☆".repeat(5 - Math.round(product.rating || 0))}
                        </span>
                        <span>({product.reviewCount || 0})</span>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Features Banner */}
      <section className="container" style={{ padding: "60px 0" }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
          gap: "20px"
        }}>
          {[
            { icon: <Truck size={28} />, title: "Free Shipping", desc: "On orders over $100" },
            { icon: <Shield size={28} />, title: "Secure Checkout", desc: "256-bit encryption" },
            { icon: <Star size={28} />, title: "Premium Quality", desc: "Certified genuine gear" },
            { icon: <Zap size={28} />, title: "Fast Delivery", desc: "2-3 business days" },
          ].map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "16px",
                padding: "24px",
                background: "var(--bg-card)",
                border: "1px solid var(--border-subtle)",
                borderRadius: "var(--radius-md)"
              }}
            >
              <div style={{
                color: "var(--accent-primary)",
                background: "rgba(0,240,255,0.1)",
                padding: "12px",
                borderRadius: "12px"
              }}>{f.icon}</div>
              <div>
                <div style={{ fontWeight: 600, marginBottom: "4px" }}>{f.title}</div>
                <div style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>{f.desc}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="cta-section container">
        <motion.div
          className="cta-box"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2>Ready to <span className="glow-text">Dominate</span>?</h2>
          <p>Join thousands of athletes who trust APEX for their sporting needs.</p>
          <Link to="/register" className="btn btn-primary btn-lg">
            Get Started <ArrowRight size={18} />
          </Link>
        </motion.div>
      </section>
    </div>
  );
}

import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, ShoppingCart } from "lucide-react";
import { collection, getDocs, query, orderBy } from "firebase/firestore";
import { db } from "../../config/firebase";
import type { Product } from "../../types";
import { useCart } from "../../context/CartContext";
import "./Products.css";

const sportsList = ["Running", "Basketball", "Football", "Tennis", "Swimming", "Training"];
const categoryList = ["Shoes", "Apparel", "Equipment", "Accessories"];

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [filtered, setFiltered] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState(searchParams.get("q") || "");
  const [selectedSports, setSelectedSports] = useState<string[]>(
    searchParams.get("sport") ? [searchParams.get("sport")!] : []
  );
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const { addItem } = useCart();

  useEffect(() => {
    async function fetchProducts() {
      try {
        const q = query(collection(db, "products"), orderBy("name"));
        const snap = await getDocs(q);
        setProducts(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Product)));
      } catch {
        // empty store
      }
      setLoading(false);
    }
    fetchProducts();
  }, []);

  useEffect(() => {
    let result = [...products];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(term) ||
          p.brand?.toLowerCase().includes(term) ||
          p.description?.toLowerCase().includes(term)
      );
    }

    if (selectedSports.length > 0) {
      result = result.filter((p) => selectedSports.includes(p.sport?.toLowerCase()));
    }

    if (selectedCategories.length > 0) {
      result = result.filter((p) => selectedCategories.includes(p.category?.toLowerCase()));
    }

    if (priceMin) result = result.filter((p) => p.price >= Number(priceMin));
    if (priceMax) result = result.filter((p) => p.price <= Number(priceMax));

    switch (sortBy) {
      case "price-asc":
        result.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        result.sort((a, b) => b.price - a.price);
        break;
      case "rating":
        result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      default:
        result.sort((a, b) => a.name.localeCompare(b.name));
    }

    setFiltered(result);
  }, [products, searchTerm, selectedSports, selectedCategories, priceMin, priceMax, sortBy]);

  function toggleSport(sport: string) {
    const s = sport.toLowerCase();
    setSelectedSports((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));
  }

  function toggleCategory(cat: string) {
    const c = cat.toLowerCase();
    setSelectedCategories((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));
  }

  return (
    <div className="products-page">
      <div className="container">
        <motion.div
          className="products-header"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1>
            All <span className="glow-text">Products</span>
          </h1>
          <p>Discover premium athletic gear engineered for champions</p>
        </motion.div>

        <div className="products-search">
          <Search size={20} className="search-icon" />
          <input
            type="text"
            placeholder="Search products, brands, sports..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="products-layout">
          {/* Filters */}
          <aside className="filters-sidebar">
            <div className="filter-group">
              <h3>Sport</h3>
              {sportsList.map((sport) => (
                <div
                  key={sport}
                  className={`filter-option ${selectedSports.includes(sport.toLowerCase()) ? "active" : ""}`}
                  onClick={() => toggleSport(sport)}
                >
                  <div className="custom-checkbox">
                    <div className="check-mark" style={{ background: "var(--bg-primary)", borderRadius: "2px" }} />
                  </div>
                  {sport}
                </div>
              ))}
            </div>

            <div className="filter-group">
              <h3>Category</h3>
              {categoryList.map((cat) => (
                <div
                  key={cat}
                  className={`filter-option ${selectedCategories.includes(cat.toLowerCase()) ? "active" : ""}`}
                  onClick={() => toggleCategory(cat)}
                >
                  <div className="custom-checkbox">
                    <div className="check-mark" style={{ background: "var(--bg-primary)", borderRadius: "2px" }} />
                  </div>
                  {cat}
                </div>
              ))}
            </div>

            <div className="filter-group">
              <h3>Price Range</h3>
              <div className="price-inputs">
                <input
                  type="number"
                  placeholder="Min"
                  value={priceMin}
                  onChange={(e) => setPriceMin(e.target.value)}
                />
                <span>–</span>
                <input
                  type="number"
                  placeholder="Max"
                  value={priceMax}
                  onChange={(e) => setPriceMax(e.target.value)}
                />
              </div>
            </div>
          </aside>

          {/* Products */}
          <div>
            <div className="products-toolbar">
              <span className="products-count">{filtered.length} products</span>
              <select className="sort-select" value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
                <option value="name">Sort by Name</option>
                <option value="price-asc">Price: Low → High</option>
                <option value="price-desc">Price: High → Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>

            {loading ? (
              <div className="products-grid-main">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="skeleton" style={{ height: 320, borderRadius: "var(--radius-lg)" }} />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">🔍</div>
                <h3>No products found</h3>
                <p>Try adjusting your filters or search terms</p>
              </div>
            ) : (
              <div className="products-grid-main">
                {filtered.map((product, i) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                  >
                    <Link to={`/products/${product.id}`}>
                      <div className="product-card">
                        <div className="product-card-image">
                          {product.images?.[0] ? (
                            <img src={product.images[0]} alt={product.name} />
                          ) : (
                            <div style={{ fontSize: "3rem", opacity: 0.3 }}>📦</div>
                          )}
                          {product.compareAtPrice && (
                            <span className="product-badge badge badge-danger">Sale</span>
                          )}
                          <button
                            className="quick-add"
                            onClick={(e) => {
                              e.preventDefault();
                              addItem(product);
                            }}
                          >
                            <ShoppingCart size={18} />
                          </button>
                        </div>
                        <div className="product-card-body">
                          <div className="product-card-brand">{product.brand}</div>
                          <div className="product-card-name">{product.name}</div>
                          <div className="product-card-price">
                            <span className="current">${product.price.toFixed(2)}</span>
                            {product.compareAtPrice && (
                              <span className="original">${product.compareAtPrice.toFixed(2)}</span>
                            )}
                          </div>
                          <div className="product-card-rating">
                            <span className="stars">
                              {"★".repeat(Math.round(product.rating || 0))}
                              {"☆".repeat(5 - Math.round(product.rating || 0))}
                            </span>
                            <span>({product.reviewCount || 0})</span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

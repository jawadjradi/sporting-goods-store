import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ShoppingCart, Star, ArrowLeft, Minus, Plus, Check } from "lucide-react";
import { doc, getDoc, collection, getDocs, query, where, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../../config/firebase";
import type { Product, Review } from "../../types";
import { useCart } from "../../context/CartContext";
import { useAuth } from "../../context/AuthContext";
import "./ProductDetail.css";

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [reviewText, setReviewText] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [submitting, setSubmitting] = useState(false);
  const [added, setAdded] = useState(false);
  const { addItem } = useCart();
  const { currentUser } = useAuth();

  useEffect(() => {
    async function fetchData() {
      if (!id) return;
      try {
        const docSnap = await getDoc(doc(db, "products", id));
        if (docSnap.exists()) {
          setProduct({ id: docSnap.id, ...docSnap.data() } as Product);
        }
        const reviewsSnap = await getDocs(query(collection(db, "reviews"), where("productId", "==", id)));
        setReviews(reviewsSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Review)));
      } catch {
        // handle error
      }
      setLoading(false);
    }
    fetchData();
  }, [id]);

  function handleAddToCart() {
    if (!product) return;
    addItem(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  }

  async function handleSubmitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!currentUser || !product || !reviewText.trim()) return;
    setSubmitting(true);
    try {
      await addDoc(collection(db, "reviews"), {
        userId: currentUser.uid,
        userName: currentUser.displayName || "Anonymous",
        userPhoto: currentUser.photoURL || null,
        productId: product.id,
        rating: reviewRating,
        comment: reviewText.trim(),
        createdAt: serverTimestamp(),
      });
      setReviewText("");
      // Refresh reviews
      const reviewsSnap = await getDocs(query(collection(db, "reviews"), where("productId", "==", id)));
      setReviews(reviewsSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Review)));
    } catch {
      // handle error
    }
    setSubmitting(false);
  }

  if (loading) {
    return (
      <div className="page-wrapper container">
        <div style={{ display: "flex", gap: 40 }}>
          <div className="skeleton" style={{ width: "50%", height: 500, borderRadius: "var(--radius-lg)" }} />
          <div style={{ flex: 1 }}>
            <div className="skeleton" style={{ height: 40, width: "80%", marginBottom: 16 }} />
            <div className="skeleton" style={{ height: 20, width: "40%", marginBottom: 24 }} />
            <div className="skeleton" style={{ height: 100, marginBottom: 16 }} />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="page-wrapper container">
        <div className="empty-state">
          <div className="empty-icon">🤷</div>
          <h3>Product not found</h3>
          <Link to="/products" className="btn btn-primary" style={{ marginTop: 16 }}>Back to Products</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="page-wrapper">
      <div className="container">
        <Link to="/products" className="back-link">
          <ArrowLeft size={18} /> Back to Products
        </Link>

        <motion.div
          className="product-detail-grid"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Images */}
          <div className="product-images">
            <div className="product-main-image">
              {product.images?.[selectedImage] ? (
                <img src={product.images[selectedImage]} alt={product.name} />
              ) : (
                <div style={{ fontSize: "5rem", opacity: 0.3 }}>📦</div>
              )}
            </div>
            {product.images?.length > 1 && (
              <div className="product-thumbnails">
                {product.images.map((img, i) => (
                  <div
                    key={i}
                    className={`thumbnail ${i === selectedImage ? "active" : ""}`}
                    onClick={() => setSelectedImage(i)}
                  >
                    <img src={img} alt="" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="product-info">
            <div className="product-info-brand">{product.brand}</div>
            <h1 className="product-info-name">{product.name}</h1>

            <div className="product-info-rating">
              <div className="stars-row">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={18}
                    fill={i < Math.round(product.rating || 0) ? "#ffaa00" : "none"}
                    color={i < Math.round(product.rating || 0) ? "#ffaa00" : "#5a5a7a"}
                  />
                ))}
              </div>
              <span>{reviews.length} reviews</span>
            </div>

            <div className="product-info-price">
              <span className="current-price">${product.price.toFixed(2)}</span>
              {product.compareAtPrice && (
                <>
                  <span className="original-price">${product.compareAtPrice.toFixed(2)}</span>
                  <span className="badge badge-danger">
                    {Math.round((1 - product.price / product.compareAtPrice) * 100)}% OFF
                  </span>
                </>
              )}
            </div>

            <p className="product-info-desc">{product.description}</p>

            <div className="product-info-stock">
              {product.stock > 0 ? (
                <span className="badge badge-success">✓ In Stock ({product.stock} available)</span>
              ) : (
                <span className="badge badge-danger">Out of Stock</span>
              )}
            </div>

            <div className="product-info-meta">
              {product.sport && (
                <div><span className="meta-label">Sport:</span> {product.sport}</div>
              )}
              {product.category && (
                <div><span className="meta-label">Category:</span> {product.category}</div>
              )}
            </div>

            {product.stock > 0 && (
              <div className="product-actions">
                <div className="quantity-selector">
                  <button onClick={() => setQuantity(Math.max(1, quantity - 1))}><Minus size={16} /></button>
                  <span>{quantity}</span>
                  <button onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}><Plus size={16} /></button>
                </div>
                <button className="btn btn-primary btn-lg" onClick={handleAddToCart} style={{ flex: 1 }}>
                  {added ? (
                    <><Check size={18} /> Added!</>
                  ) : (
                    <><ShoppingCart size={18} /> Add to Cart</>
                  )}
                </button>
              </div>
            )}
          </div>
        </motion.div>

        {/* Reviews */}
        <div className="reviews-section">
          <h2>Customer Reviews</h2>

          {currentUser && (
            <form className="review-form" onSubmit={handleSubmitReview}>
              <div className="review-rating-select">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={24}
                    fill={i < reviewRating ? "#ffaa00" : "none"}
                    color={i < reviewRating ? "#ffaa00" : "#5a5a7a"}
                    style={{ cursor: "pointer" }}
                    onClick={() => setReviewRating(i + 1)}
                  />
                ))}
              </div>
              <textarea
                className="input-field"
                placeholder="Write your review..."
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                rows={3}
                required
              />
              <button className="btn btn-primary btn-sm" type="submit" disabled={submitting}>
                {submitting ? "Posting..." : "Post Review"}
              </button>
            </form>
          )}

          {reviews.length === 0 ? (
            <p style={{ color: "var(--text-muted)", padding: "24px 0" }}>No reviews yet. Be the first!</p>
          ) : (
            <div className="reviews-list">
              {reviews.map((review) => (
                <div key={review.id} className="review-card">
                  <div className="review-header">
                    <div className="review-author">
                      {review.userPhoto ? (
                        <img src={review.userPhoto} alt="" className="review-avatar" />
                      ) : (
                        <div className="review-avatar-placeholder">
                          {(review.userName || "A")[0].toUpperCase()}
                        </div>
                      )}
                      <div>
                        <div className="review-name">{review.userName}</div>
                        <div className="review-stars">
                          {"★".repeat(review.rating)}{"☆".repeat(5 - review.rating)}
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="review-comment">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

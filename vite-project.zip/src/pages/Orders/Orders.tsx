import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Package, ChevronDown, ChevronUp, CheckCircle } from "lucide-react";
import { collection, getDocs, query, where, orderBy } from "firebase/firestore";
import { db } from "../../config/firebase";
import { useAuth } from "../../context/AuthContext";
import type { Order } from "../../types";
import "./Orders.css";

export default function OrdersPage() {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [searchParams] = useSearchParams();
  const successId = searchParams.get("success");

  useEffect(() => {
    async function fetchOrders() {
      if (!currentUser) return;
      try {
        const q = query(
          collection(db, "orders"),
          where("userId", "==", currentUser.uid),
          orderBy("createdAt", "desc")
        );
        const snap = await getDocs(q);
        setOrders(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Order)));
      } catch {
        // handle
      }
      setLoading(false);
    }
    fetchOrders();
  }, [currentUser]);

  const statusColor: Record<string, string> = {
    pending: "badge-warning",
    processing: "badge-primary",
    completed: "badge-success",
    cancelled: "badge-danger",
  };

  return (
    <div className="page-wrapper">
      <div className="container">
        {successId && (
          <motion.div
            className="order-success-banner"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <CheckCircle size={24} />
            <div>
              <h3>Order Placed Successfully!</h3>
              <p>Your order #{successId.slice(0, 8)} has been confirmed.</p>
            </div>
          </motion.div>
        )}

        <motion.h1
          className="orders-title"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          My <span className="glow-text">Orders</span>
        </motion.h1>

        {loading ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="skeleton" style={{ height: 80, borderRadius: "var(--radius-lg)" }} />
            ))}
          </div>
        ) : orders.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📦</div>
            <h3>No orders yet</h3>
            <p>Start shopping to see your orders here</p>
            <Link to="/products" className="btn btn-primary" style={{ marginTop: 16 }}>
              Browse Products
            </Link>
          </div>
        ) : (
          <div className="orders-list">
            {orders.map((order, i) => (
              <motion.div
                key={order.id}
                className="order-card"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <div
                  className="order-card-header"
                  onClick={() => setExpandedOrder(expandedOrder === order.id ? null : order.id)}
                >
                  <div className="order-meta">
                    <Package size={20} style={{ color: "var(--accent-primary)" }} />
                    <div>
                      <div className="order-id">#{order.id.slice(0, 8).toUpperCase()}</div>
                      <div className="order-date">
                        {(order.createdAt as any)?.toDate ? (order.createdAt as any).toDate().toLocaleDateString() : "Recent"}
                      </div>
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                    <span className={`badge ${statusColor[order.status] || "badge-primary"}`}>
                      {order.status}
                    </span>
                    <span className="order-total">${order.total?.toFixed(2)}</span>
                    {expandedOrder === order.id ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                  </div>
                </div>

                <AnimatePresence>
                  {expandedOrder === order.id && (
                    <motion.div
                      className="order-card-details"
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      style={{ overflow: "hidden" }}
                    >
                      <div className="order-items-list">
                        {order.items?.map((item, idx) => (
                          <div key={idx} className="order-item-row">
                            <div className="order-item-img">
                              {item.productImage ? (
                                <img src={item.productImage} alt="" />
                              ) : (
                                <span>📦</span>
                              )}
                            </div>
                            <div className="order-item-info">
                              <div>{item.productName}</div>
                              <div style={{ color: "var(--text-muted)", fontSize: "0.85rem" }}>
                                Qty: {item.quantity} × ${item.price.toFixed(2)}
                              </div>
                            </div>
                            <div style={{ fontWeight: 600 }}>
                              ${(item.price * item.quantity).toFixed(2)}
                            </div>
                          </div>
                        ))}
                      </div>
                      {order.shippingAddress && (
                        <div className="order-shipping">
                          <h4>Shipping to</h4>
                          <p>
                            {order.shippingAddress.fullName}<br />
                            {order.shippingAddress.street}<br />
                            {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}
                          </p>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

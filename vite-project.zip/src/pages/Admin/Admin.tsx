import { useState, useEffect } from "react";
import { NavLink, Outlet } from "react-router-dom";
import { motion } from "framer-motion";
import {
  LayoutDashboard, Package, ShoppingCart, Layers, Star, BarChart3,
  Plus, Pencil, Trash2, AlertTriangle, Save
} from "lucide-react";
import {
  collection, getDocs, addDoc, updateDoc, deleteDoc, doc, serverTimestamp, query, orderBy, where
} from "firebase/firestore";
import { db } from "../../config/firebase";
import type { Product, Order, Review } from "../../types";
import "./Admin.css";

/* ─── Admin Layout ─── */
export function AdminLayout() {
  return (
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <div className="admin-sidebar-title">Admin Panel</div>
        <nav className="admin-nav">
          <NavLink to="/admin" end><LayoutDashboard size={18} /> Dashboard</NavLink>
          <NavLink to="/admin/products"><Package size={18} /> Products</NavLink>
          <NavLink to="/admin/orders"><ShoppingCart size={18} /> Orders</NavLink>
          <NavLink to="/admin/inventory"><BarChart3 size={18} /> Inventory</NavLink>
          <NavLink to="/admin/categories"><Layers size={18} /> Categories</NavLink>
          <NavLink to="/admin/reviews"><Star size={18} /> Reviews</NavLink>
        </nav>
      </aside>
      <main className="admin-content">
        <Outlet />
      </main>
    </div>
  );
}

/* ─── Dashboard ─── */
export function AdminDashboard() {
  const [stats, setStats] = useState({ products: 0, orders: 0, revenue: 0, lowStock: 0 });

  useEffect(() => {
    async function load() {
      try {
        const productsSnap = await getDocs(collection(db, "products"));
        const ordersSnap = await getDocs(collection(db, "orders"));
        
        let revenue = 0;
        ordersSnap.docs.forEach((d) => { revenue += d.data().total || 0; });
        
        let lowStock = 0;
        productsSnap.docs.forEach((d) => { if ((d.data().stock || 0) < 10) lowStock++; });

        setStats({
          products: productsSnap.size,
          orders: ordersSnap.size,
          revenue,
          lowStock,
        });
      } catch {}
    }
    load();
  }, []);

  return (
    <div>
      <div className="admin-page-header">
        <h1><span className="glow-text">Dashboard</span></h1>
      </div>
      <div className="admin-stats">
        {[
          { icon: "📦", label: "Total Products", value: stats.products, color: "rgba(0,240,255,0.15)" },
          { icon: "🛒", label: "Total Orders", value: stats.orders, color: "rgba(123,45,255,0.15)" },
          { icon: "💰", label: "Revenue", value: `$${stats.revenue.toFixed(2)}`, color: "rgba(0,255,136,0.15)" },
          { icon: "⚠️", label: "Low Stock Items", value: stats.lowStock, color: "rgba(255,170,0,0.15)" },
        ].map((s, i) => (
          <motion.div
            key={i}
            className="stat-card"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
          >
            <div className="stat-card-icon" style={{ background: s.color }}>{s.icon}</div>
            <div className="stat-card-value">{s.value}</div>
            <div className="stat-card-label">{s.label}</div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ─── Products Management ─── */
export function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [form, setForm] = useState({
    name: "", description: "", price: "", compareAtPrice: "", brand: "",
    sport: "", category: "", stock: "", images: "", featured: false,
  });

  async function loadProducts() {
    const snap = await getDocs(query(collection(db, "products"), orderBy("name")));
    setProducts(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Product)));
  }

  useEffect(() => { loadProducts(); }, []);

  function openCreate() {
    setEditing(null);
    setForm({ name: "", description: "", price: "", compareAtPrice: "", brand: "", sport: "", category: "", stock: "", images: "", featured: false });
    setShowModal(true);
  }

  function openEdit(p: Product) {
    setEditing(p);
    setForm({
      name: p.name, description: p.description || "", price: String(p.price),
      compareAtPrice: p.compareAtPrice ? String(p.compareAtPrice) : "",
      brand: p.brand || "", sport: p.sport || "", category: p.category || "",
      stock: String(p.stock || 0), images: p.images?.join(", ") || "", featured: p.featured || false,
    });
    setShowModal(true);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    const data = {
      name: form.name,
      description: form.description,
      price: Number(form.price),
      compareAtPrice: form.compareAtPrice ? Number(form.compareAtPrice) : null,
      brand: form.brand,
      sport: form.sport.toLowerCase(),
      category: form.category.toLowerCase(),
      stock: Number(form.stock),
      images: form.images.split(",").map((s) => s.trim()).filter(Boolean),
      featured: form.featured,
      rating: 0,
      reviewCount: 0,
      updatedAt: serverTimestamp(),
    };

    if (editing) {
      await updateDoc(doc(db, "products", editing.id), data);
    } else {
      await addDoc(collection(db, "products"), { ...data, createdAt: serverTimestamp() });
    }
    setShowModal(false);
    loadProducts();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this product?")) return;
    await deleteDoc(doc(db, "products", id));
    loadProducts();
  }

  return (
    <div>
      <div className="admin-page-header">
        <h1>Products</h1>
        <button className="btn btn-primary" onClick={openCreate}>
          <Plus size={16} /> Add Product
        </button>
      </div>

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Sport</th>
              <th>Category</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>
                  <div className="product-cell">
                    <div className="product-thumb">
                      {p.images?.[0] ? <img src={p.images[0]} alt="" /> : "📦"}
                    </div>
                    <div>
                      <div style={{ fontWeight: 600 }}>{p.name}</div>
                      <div style={{ fontSize: "0.8rem", color: "var(--text-muted)" }}>{p.brand}</div>
                    </div>
                  </div>
                </td>
                <td>${p.price?.toFixed(2)}</td>
                <td>
                  <span className={`badge ${(p.stock || 0) < 10 ? "badge-danger" : "badge-success"}`}>
                    {p.stock}
                  </span>
                </td>
                <td>{p.sport}</td>
                <td>{p.category}</td>
                <td>
                  <div className="actions-cell">
                    <button className="btn btn-ghost btn-sm" onClick={() => openEdit(p)}><Pencil size={14} /></button>
                    <button className="btn btn-ghost btn-sm" onClick={() => handleDelete(p.id)}><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {products.length === 0 && (
          <div className="empty-state" style={{ padding: "48px" }}>
            <p>No products yet. Click "Add Product" to create one.</p>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <motion.div
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <h2>{editing ? "Edit Product" : "Add Product"}</h2>
            <form onSubmit={handleSave} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div className="input-group">
                <label>Name</label>
                <input className="input-field" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div className="input-group">
                <label>Description</label>
                <textarea className="input-field" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div className="input-group">
                  <label>Price</label>
                  <input className="input-field" type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} required />
                </div>
                <div className="input-group">
                  <label>Compare At Price</label>
                  <input className="input-field" type="number" step="0.01" value={form.compareAtPrice} onChange={(e) => setForm({ ...form, compareAtPrice: e.target.value })} />
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div className="input-group">
                  <label>Brand</label>
                  <input className="input-field" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
                </div>
                <div className="input-group">
                  <label>Stock</label>
                  <input className="input-field" type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} required />
                </div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div className="input-group">
                  <label>Sport</label>
                  <input className="input-field" value={form.sport} onChange={(e) => setForm({ ...form, sport: e.target.value })} placeholder="e.g. running" />
                </div>
                <div className="input-group">
                  <label>Category</label>
                  <input className="input-field" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. shoes" />
                </div>
              </div>
              <div className="input-group">
                <label>Image URLs (comma separated)</label>
                <input className="input-field" value={form.images} onChange={(e) => setForm({ ...form, images: e.target.value })} placeholder="https://..." />
              </div>
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", color: "var(--text-secondary)" }}>
                <input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} />
                Featured product
              </label>
              <div className="modal-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary"><Save size={16} /> {editing ? "Update" : "Create"}</button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}

/* ─── Orders Management ─── */
export function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([]);

  async function loadOrders() {
    const snap = await getDocs(query(collection(db, "orders"), orderBy("createdAt", "desc")));
    setOrders(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Order)));
  }

  useEffect(() => { loadOrders(); }, []);

  async function updateStatus(orderId: string, status: string) {
    await updateDoc(doc(db, "orders", orderId), { status, updatedAt: serverTimestamp() });
    loadOrders();
  }

  const statusColor: Record<string, string> = {
    pending: "badge-warning",
    processing: "badge-primary",
    completed: "badge-success",
    cancelled: "badge-danger",
  };

  return (
    <div>
      <div className="admin-page-header">
        <h1>Orders</h1>
      </div>
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Items</th>
              <th>Total</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td style={{ fontFamily: "var(--font-heading)", fontSize: "0.85rem" }}>#{o.id.slice(0, 8).toUpperCase()}</td>
                <td>{o.items?.length || 0} items</td>
                <td>${o.total?.toFixed(2)}</td>
                <td><span className={`badge ${statusColor[o.status] || ""}`}>{o.status}</span></td>
                <td>
                  <select
                    className="sort-select"
                    value={o.status}
                    onChange={(e) => updateStatus(o.id, e.target.value)}
                    style={{ fontSize: "0.8rem", padding: "6px 10px" }}
                  >
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {orders.length === 0 && (
          <div className="empty-state" style={{ padding: "48px" }}>
            <p>No orders yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Inventory ─── */
export function AdminInventory() {
  const [products, setProducts] = useState<Product[]>([]);
  const [editingStock, setEditingStock] = useState<Record<string, string>>({});

  async function loadProducts() {
    const snap = await getDocs(query(collection(db, "products"), orderBy("stock")));
    setProducts(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Product)));
  }

  useEffect(() => { loadProducts(); }, []);

  async function updateStock(productId: string) {
    const newStock = Number(editingStock[productId]);
    if (isNaN(newStock)) return;
    
    const product = products.find((p) => p.id === productId);
    const diff = newStock - (product?.stock || 0);
    
    await updateDoc(doc(db, "products", productId), { stock: newStock });
    await addDoc(collection(db, "inventoryLogs"), {
      productId,
      type: "manual",
      quantity: diff,
      note: `Manual stock update to ${newStock}`,
      createdAt: serverTimestamp(),
    });
    
    setEditingStock((prev) => {
      const next = { ...prev };
      delete next[productId];
      return next;
    });
    loadProducts();
  }

  return (
    <div>
      <div className="admin-page-header">
        <h1>Inventory</h1>
      </div>

      {products.filter((p) => (p.stock || 0) < 10).length > 0 && (
        <div style={{
          display: "flex", alignItems: "center", gap: 12, padding: "16px 20px",
          background: "rgba(255,170,0,0.08)", border: "1px solid rgba(255,170,0,0.2)",
          borderRadius: "var(--radius-md)", marginBottom: 24, color: "var(--accent-warning)"
        }}>
          <AlertTriangle size={20} />
          <span>{products.filter((p) => (p.stock || 0) < 10).length} products have low stock (&lt; 10 units)</span>
        </div>
      )}

      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Current Stock</th>
              <th>Status</th>
              <th>Update Stock</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>
                  <div className="product-cell">
                    <div className="product-thumb">
                      {p.images?.[0] ? <img src={p.images[0]} alt="" /> : "📦"}
                    </div>
                    <span style={{ fontWeight: 500 }}>{p.name}</span>
                  </div>
                </td>
                <td style={{ fontFamily: "var(--font-heading)", fontWeight: 700 }}>{p.stock}</td>
                <td>
                  <span className={`badge ${(p.stock || 0) === 0 ? "badge-danger" : (p.stock || 0) < 10 ? "badge-warning" : "badge-success"}`}>
                    {(p.stock || 0) === 0 ? "Out of Stock" : (p.stock || 0) < 10 ? "Low Stock" : "In Stock"}
                  </span>
                </td>
                <td>
                  <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <input
                      className="input-field"
                      type="number"
                      placeholder={String(p.stock)}
                      value={editingStock[p.id] || ""}
                      onChange={(e) => setEditingStock({ ...editingStock, [p.id]: e.target.value })}
                      style={{ width: 100, padding: "8px 12px" }}
                    />
                    {editingStock[p.id] !== undefined && (
                      <button className="btn btn-primary btn-sm" onClick={() => updateStock(p.id)}>Update</button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ─── Categories & Sports Management ─── */
export function AdminCategories() {
  const [categories, setCategories] = useState<{ id: string; name: string; type: string }[]>([]);
  const [newName, setNewName] = useState("");
  const [newType, setNewType] = useState<"category" | "sport">("category");

  async function load() {
    const snap = await getDocs(collection(db, "taxonomies"));
    setCategories(snap.docs.map((d) => ({ id: d.id, ...d.data() } as any)));
  }

  useEffect(() => { load(); }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!newName.trim()) return;
    await addDoc(collection(db, "taxonomies"), {
      name: newName.trim(),
      slug: newName.trim().toLowerCase().replace(/\s+/g, "-"),
      type: newType,
      createdAt: serverTimestamp(),
    });
    setNewName("");
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this item?")) return;
    await deleteDoc(doc(db, "taxonomies", id));
    load();
  }

  const cats = categories.filter((c) => c.type === "category");
  const sports = categories.filter((c) => c.type === "sport");

  return (
    <div>
      <div className="admin-page-header">
        <h1>Categories & Sports</h1>
      </div>

      <form onSubmit={handleAdd} style={{ display: "flex", gap: 12, marginBottom: 32 }}>
        <input
          className="input-field"
          placeholder="Name"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          required
          style={{ flex: 1 }}
        />
        <select className="sort-select" value={newType} onChange={(e) => setNewType(e.target.value as any)}>
          <option value="category">Category</option>
          <option value="sport">Sport</option>
        </select>
        <button className="btn btn-primary" type="submit"><Plus size={16} /> Add</button>
      </form>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div>
          <h3 style={{ fontFamily: "var(--font-heading)", fontSize: "0.9rem", marginBottom: 16 }}>Categories</h3>
          {cats.map((c) => (
            <div key={c.id} style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "12px 16px", background: "var(--bg-card)", border: "1px solid var(--border-subtle)",
              borderRadius: "var(--radius-md)", marginBottom: 8
            }}>
              <span>{c.name}</span>
              <button className="btn btn-ghost btn-sm" onClick={() => handleDelete(c.id)}><Trash2 size={14} /></button>
            </div>
          ))}
          {cats.length === 0 && <p style={{ color: "var(--text-muted)" }}>No categories yet</p>}
        </div>
        <div>
          <h3 style={{ fontFamily: "var(--font-heading)", fontSize: "0.9rem", marginBottom: 16 }}>Sports</h3>
          {sports.map((c) => (
            <div key={c.id} style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "12px 16px", background: "var(--bg-card)", border: "1px solid var(--border-subtle)",
              borderRadius: "var(--radius-md)", marginBottom: 8
            }}>
              <span>{c.name}</span>
              <button className="btn btn-ghost btn-sm" onClick={() => handleDelete(c.id)}><Trash2 size={14} /></button>
            </div>
          ))}
          {sports.length === 0 && <p style={{ color: "var(--text-muted)" }}>No sports yet</p>}
        </div>
      </div>
    </div>
  );
}

/* ─── Reviews Moderation ─── */
export function AdminReviews() {
  const [reviews, setReviews] = useState<(Review & { productName?: string })[]>([]);

  async function load() {
    const snap = await getDocs(query(collection(db, "reviews"), orderBy("createdAt", "desc")));
    const rev = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Review));
    
    // Get product names
    const productIds = [...new Set(rev.map((r) => r.productId))];
    const productNames: Record<string, string> = {};
    for (const pid of productIds) {
      try {
        const pDoc = await getDocs(query(collection(db, "products"), where("__name__", "==", pid)));
        if (!pDoc.empty) productNames[pid] = pDoc.docs[0].data().name;
      } catch {}
    }
    
    setReviews(rev.map((r) => ({ ...r, productName: productNames[r.productId] || r.productId })));
  }

  useEffect(() => { load(); }, []);

  async function handleDelete(id: string) {
    if (!confirm("Delete this review?")) return;
    await deleteDoc(doc(db, "reviews", id));
    load();
  }

  return (
    <div>
      <div className="admin-page-header">
        <h1>Reviews</h1>
      </div>
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>User</th>
              <th>Product</th>
              <th>Rating</th>
              <th>Comment</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {reviews.map((r) => (
              <tr key={r.id}>
                <td>{r.userName}</td>
                <td>{r.productName}</td>
                <td><span style={{ color: "var(--accent-warning)" }}>{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</span></td>
                <td style={{ maxWidth: 300, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.comment}</td>
                <td>
                  <button className="btn btn-ghost btn-sm" onClick={() => handleDelete(r.id)}>
                    <Trash2 size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {reviews.length === 0 && (
          <div className="empty-state" style={{ padding: "48px" }}>
            <p>No reviews yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}

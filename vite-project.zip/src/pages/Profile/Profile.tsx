import { useState } from "react";
import { motion } from "framer-motion";
import { Save } from "lucide-react";
import { updateProfile } from "firebase/auth";
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../../config/firebase";
import { useAuth } from "../../context/AuthContext";
import "./Profile.css";

export default function ProfilePage() {
  const { currentUser, userData } = useAuth();
  const [displayName, setDisplayName] = useState(currentUser?.displayName || "");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!currentUser) return;
    setSaving(true);
    try {
      await updateProfile(currentUser, { displayName });
      await updateDoc(doc(db, "users", currentUser.uid), { displayName });
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch {
      // handle
    }
    setSaving(false);
  }

  return (
    <div className="page-wrapper">
      <div className="container" style={{ maxWidth: 600 }}>
        <motion.h1
          className="profile-title"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          My <span className="glow-text">Profile</span>
        </motion.h1>

        <motion.div
          className="profile-card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="profile-header">
            <div className="profile-avatar-wrap">
              {currentUser?.photoURL ? (
                <img src={currentUser.photoURL} alt="" className="profile-avatar" />
              ) : (
                <div className="profile-avatar-placeholder">
                  {(currentUser?.displayName || currentUser?.email || "U")[0].toUpperCase()}
                </div>
              )}
            </div>
            <div>
              <h2>{currentUser?.displayName || "User"}</h2>
              <p>{currentUser?.email}</p>
              <span className={`badge ${userData?.role === "admin" ? "badge-primary" : "badge-success"}`}>
                {userData?.role || "customer"}
              </span>
            </div>
          </div>

          <form className="profile-form" onSubmit={handleSave}>
            <div className="input-group">
              <label>Display Name</label>
              <input
                className="input-field"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>
            <div className="input-group">
              <label>Email</label>
              <input
                className="input-field"
                type="email"
                value={currentUser?.email || ""}
                disabled
                style={{ opacity: 0.6 }}
              />
            </div>
            <button className="btn btn-primary" type="submit" disabled={saving}>
              {saved ? <><Save size={16} /> Saved!</> : saving ? "Saving..." : <><Save size={16} /> Save Changes</>}
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}

import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Trash2, Minus, Plus, ShoppingBag, ArrowRight } from "lucide-react";
import { useCart } from "../../context/CartContext";
import "./Cart.css";

export default function CartPage() {
  const { items, removeItem, updateQuantity, total, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="page-wrapper container">
        <motion.div
          className="empty-cart"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="empty-cart-icon">🛒</div>
          <h2>Your cart is empty</h2>
          <p>Looks like you haven't added anything yet.</p>
          <Link to="/products" className="btn btn-primary btn-lg">
            <ShoppingBag size={18} /> Browse Products
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="page-wrapper">
      <div className="container">
        <motion.h1
          className="cart-title"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          Shopping <span className="glow-text">Cart</span>
        </motion.h1>

        <div className="cart-layout">
          <div className="cart-items">
            <AnimatePresence>
              {items.map((item) => (
                <motion.div
                  key={item.productId}
                  className="cart-item"
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20, height: 0, marginBottom: 0, padding: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="cart-item-image">
                    {item.product.images?.[0] ? (
                      <img src={item.product.images[0]} alt={item.product.name} />
                    ) : (
                      <div style={{ fontSize: "2rem", opacity: 0.3 }}>📦</div>
                    )}
                  </div>
                  <div className="cart-item-info">
                    <Link to={`/products/${item.productId}`} className="cart-item-name">
                      {item.product.name}
                    </Link>
                    <div className="cart-item-brand">{item.product.brand}</div>
                    <div className="cart-item-price">${item.product.price.toFixed(2)}</div>
                  </div>
                  <div className="cart-item-actions">
                    <div className="quantity-selector">
                      <button onClick={() => updateQuantity(item.productId, item.quantity - 1)}>
                        <Minus size={14} />
                      </button>
                      <span>{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, item.quantity + 1)}>
                        <Plus size={14} />
                      </button>
                    </div>
                    <button className="btn btn-ghost btn-icon" onClick={() => removeItem(item.productId)}>
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="cart-item-total">
                    ${(item.product.price * item.quantity).toFixed(2)}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <motion.div
            className="cart-summary"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="summary-card">
              <h3>Order Summary</h3>
              <div className="summary-row">
                <span>Subtotal</span>
                <span>${total.toFixed(2)}</span>
              </div>
              <div className="summary-row">
                <span>Shipping</span>
                <span>{total >= 100 ? "Free" : "$9.99"}</span>
              </div>
              <div className="summary-divider" />
              <div className="summary-row total">
                <span>Total</span>
                <span>${(total + (total >= 100 ? 0 : 9.99)).toFixed(2)}</span>
              </div>
              {total < 100 && (
                <div className="free-shipping-notice">
                  Add ${(100 - total).toFixed(2)} more for free shipping!
                </div>
              )}
              <Link to="/checkout" className="btn btn-primary btn-lg" style={{ width: "100%", marginTop: 16 }}>
                Checkout <ArrowRight size={18} />
              </Link>
              <button
                className="btn btn-ghost btn-sm"
                onClick={clearCart}
                style={{ width: "100%", marginTop: 8 }}
              >
                Clear Cart
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

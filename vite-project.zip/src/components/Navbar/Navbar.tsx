import { useState, useEffect, useRef } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingCart, User, LogOut, Package, LayoutDashboard, Menu, X } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useCart } from "../../context/CartContext";
import "./Navbar.css";

export default function Navbar() {
  const { currentUser, userData, logout } = useAuth();
  const { itemCount } = useCart();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  async function handleLogout() {
    await logout();
    setDropdownOpen(false);
    navigate("/");
  }

  const avatarSrc = currentUser?.photoURL || userData?.photoURL || undefined;
  const displayLabel = currentUser?.displayName || userData?.displayName || currentUser?.email || userData?.email || "User";
  const avatarInitial = displayLabel[0]?.toUpperCase() || "U";

  return (
    <nav className={`navbar ${scrolled ? "scrolled" : ""}`}>
      <div className="navbar-inner">
        <Link to="/" className="navbar-logo">
          <div className="logo-icon">⚡</div>
          <span className="glow-text">APEX</span>
        </Link>

        <div className="navbar-links">
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/products">Products</NavLink>
          {currentUser && <NavLink to="/orders">Orders</NavLink>}
          {userData?.role === "admin" && <NavLink to="/admin">Admin</NavLink>}
        </div>

        <div className="navbar-actions">
          <button className="cart-btn" onClick={() => navigate("/cart")}>
            <ShoppingCart size={20} />
            <AnimatePresence>
              {itemCount > 0 && (
                <motion.span
                  className="cart-badge"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  key={itemCount}
                >
                  {itemCount}
                </motion.span>
              )}
            </AnimatePresence>
          </button>

          {currentUser ? (
            <div className="user-menu" ref={dropdownRef}>
              {avatarSrc ? (
                <img
                  src={avatarSrc}
                  alt={displayLabel}
                  className="user-avatar"
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                />
              ) : (
                <div className="user-avatar-placeholder" onClick={() => setDropdownOpen(!dropdownOpen)}>
                  {avatarInitial}
                </div>
              )}

              <AnimatePresence>
                {dropdownOpen && (
                  <motion.div
                    className="user-dropdown"
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.15 }}
                  >
                    <Link to="/profile" onClick={() => setDropdownOpen(false)}>
                      <User size={16} /> Profile
                    </Link>
                    <Link to="/orders" onClick={() => setDropdownOpen(false)}>
                      <Package size={16} /> Orders
                    </Link>
                    {userData?.role === "admin" && (
                      <Link to="/admin" onClick={() => setDropdownOpen(false)}>
                        <LayoutDashboard size={16} /> Admin Panel
                      </Link>
                    )}
                    <div className="divider" />
                    <button onClick={handleLogout}>
                      <LogOut size={16} /> Sign Out
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ) : (
            <Link to="/login" className="btn btn-primary btn-sm">Sign In</Link>
          )}

          <button className="mobile-toggle" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            style={{ overflow: "hidden", background: "var(--bg-card)", borderBottom: "1px solid var(--border-subtle)" }}
          >
            <div style={{ padding: "16px 24px", display: "flex", flexDirection: "column", gap: "8px" }}>
              <NavLink to="/" onClick={() => setMobileOpen(false)}>Home</NavLink>
              <NavLink to="/products" onClick={() => setMobileOpen(false)}>Products</NavLink>
              {currentUser && <NavLink to="/orders" onClick={() => setMobileOpen(false)}>Orders</NavLink>}
              {userData?.role === "admin" && <NavLink to="/admin" onClick={() => setMobileOpen(false)}>Admin</NavLink>}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

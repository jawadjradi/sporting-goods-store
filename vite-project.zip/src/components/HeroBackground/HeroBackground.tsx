import { useRef, useEffect } from "react";
import * as THREE from "three";

const PARTICLE_COUNT = 1200;

export default function HeroBackground() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    /* ---------- Renderer ---------- */
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    /* ---------- Scene & Camera ---------- */
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 50;

    /* ---------- Mouse tracking ---------- */
    const mouse = new THREE.Vector2(0, 0);
    const targetRotation = new THREE.Vector2(0, 0);

    function onPointerMove(e: PointerEvent) {
      mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.y = -(e.clientY / window.innerHeight) * 2 + 1;
    }
    window.addEventListener("pointermove", onPointerMove);

    /* ---------- Particles ---------- */
    const positions = new Float32Array(PARTICLE_COUNT * 3);
    const colors = new Float32Array(PARTICLE_COUNT * 3);
    const sizes = new Float32Array(PARTICLE_COUNT);

    const cyan = new THREE.Color(0x00f0ff);
    const purple = new THREE.Color(0x7b2dff);
    const pink = new THREE.Color(0xff2d7b);
    const palette = [cyan, purple, pink];

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const i3 = i * 3;
      positions[i3] = (Math.random() - 0.5) * 120;
      positions[i3 + 1] = (Math.random() - 0.5) * 120;
      positions[i3 + 2] = (Math.random() - 0.5) * 80;

      const color = palette[Math.floor(Math.random() * palette.length)];
      colors[i3] = color.r;
      colors[i3 + 1] = color.g;
      colors[i3 + 2] = color.b;

      sizes[i] = Math.random() * 2.5 + 0.5;
    }

    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    particleGeometry.setAttribute("size", new THREE.BufferAttribute(sizes, 1));

    const particleMaterial = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uMouse: { value: new THREE.Vector2(0, 0) },
      },
      vertexShader: `
        attribute float size;
        varying vec3 vColor;
        uniform float uTime;
        uniform vec2 uMouse;

        void main() {
          vColor = color;
          vec3 pos = position;

          // Gentle floating motion
          pos.x += sin(uTime * 0.3 + position.y * 0.05) * 1.5;
          pos.y += cos(uTime * 0.2 + position.x * 0.04) * 1.5;
          pos.z += sin(uTime * 0.15 + position.x * 0.03 + position.y * 0.03) * 1.0;

          // Mouse repulsion / attraction
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          vec2 screenPos = mvPosition.xy / mvPosition.w;
          float dist = distance(screenPos, uMouse * 2.0);
          float influence = smoothstep(2.0, 0.0, dist) * 3.0;
          pos.x += uMouse.x * influence;
          pos.y += uMouse.y * influence;

          mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_PointSize = size * (40.0 / -mvPosition.z);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        varying vec3 vColor;

        void main() {
          float d = length(gl_PointCoord - vec2(0.5));
          if (d > 0.5) discard;

          float alpha = 1.0 - smoothstep(0.15, 0.5, d);
          alpha *= 0.7;
          gl_FragColor = vec4(vColor, alpha);
        }
      `,
      transparent: true,
      vertexColors: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    /* ---------- Connecting lines ---------- */
    const linePositions = new Float32Array(PARTICLE_COUNT * PARTICLE_COUNT * 3);
    const lineColors = new Float32Array(PARTICLE_COUNT * PARTICLE_COUNT * 3);
    const lineGeometry = new THREE.BufferGeometry();
    lineGeometry.setAttribute("position", new THREE.BufferAttribute(linePositions, 3));
    lineGeometry.setAttribute("color", new THREE.BufferAttribute(lineColors, 3));

    const lineMaterial = new THREE.LineBasicMaterial({
      vertexColors: true,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const lineSegments = new THREE.LineSegments(lineGeometry, lineMaterial);
    scene.add(lineSegments);

    /* ---------- Central Torus ---------- */
    const torusGeometry = new THREE.TorusKnotGeometry(8, 0.6, 120, 16, 3, 5);
    const torusMaterial = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      wireframe: true,
      transparent: true,
      opacity: 0.08,
    });
    const torus = new THREE.Mesh(torusGeometry, torusMaterial);
    scene.add(torus);

    /* ---------- Animation Loop ---------- */
    const clock = new THREE.Clock();
    let animId: number;

    function animate() {
      animId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Smooth mouse follow
      targetRotation.x += (mouse.y * 0.3 - targetRotation.x) * 0.05;
      targetRotation.y += (mouse.x * 0.3 - targetRotation.y) * 0.05;

      particles.rotation.x = targetRotation.x;
      particles.rotation.y = targetRotation.y;

      torus.rotation.x = elapsed * 0.15 + targetRotation.x * 0.5;
      torus.rotation.y = elapsed * 0.1 + targetRotation.y * 0.5;

      // Update uniforms
      particleMaterial.uniforms.uTime.value = elapsed;
      particleMaterial.uniforms.uMouse.value.set(mouse.x, mouse.y);

      // Update connecting lines between nearby particles
      const posArray = particleGeometry.attributes.position.array as Float32Array;
      let lineIdx = 0;
      const maxLines = 600;
      const connectionDist = 12;

      for (let i = 0; i < PARTICLE_COUNT && lineIdx < maxLines; i++) {
        const ix = posArray[i * 3];
        const iy = posArray[i * 3 + 1];
        const iz = posArray[i * 3 + 2];

        for (let j = i + 1; j < PARTICLE_COUNT && lineIdx < maxLines; j++) {
          const jx = posArray[j * 3];
          const jy = posArray[j * 3 + 1];
          const jz = posArray[j * 3 + 2];

          const dx = ix - jx;
          const dy = iy - jy;
          const dz = iz - jz;
          const distSq = dx * dx + dy * dy + dz * dz;

          if (distSq < connectionDist * connectionDist) {
            const li = lineIdx * 6;
            linePositions[li] = ix;
            linePositions[li + 1] = iy;
            linePositions[li + 2] = iz;
            linePositions[li + 3] = jx;
            linePositions[li + 4] = jy;
            linePositions[li + 5] = jz;

            const alpha = 1 - Math.sqrt(distSq) / connectionDist;
            lineColors[li] = 0 * alpha;
            lineColors[li + 1] = 0.94 * alpha;
            lineColors[li + 2] = 1.0 * alpha;
            lineColors[li + 3] = 0.48 * alpha;
            lineColors[li + 4] = 0.18 * alpha;
            lineColors[li + 5] = 1.0 * alpha;

            lineIdx++;
          }
        }
      }

      lineGeometry.setDrawRange(0, lineIdx * 2);
      lineGeometry.attributes.position.needsUpdate = true;
      lineGeometry.attributes.color.needsUpdate = true;

      renderer.render(scene, camera);
    }

    animate();

    /* ---------- Resize handler ---------- */
    function onResize() {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    }
    window.addEventListener("resize", onResize);

    /* ---------- Cleanup ---------- */
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("resize", onResize);
      particleGeometry.dispose();
      particleMaterial.dispose();
      lineGeometry.dispose();
      lineMaterial.dispose();
      torusGeometry.dispose();
      torusMaterial.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 0,
        pointerEvents: "none",
      }}
    />
  );
}

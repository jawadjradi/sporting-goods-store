import { Link } from "react-router-dom";
import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-glow" />
      <div className="container">
        <div className="footer-grid">
          <div className="footer-brand">
            <div className="footer-logo">
              <span className="logo-icon">⚡</span>
              <span className="glow-text">APEX</span>
            </div>
            <p>Premium sporting goods for athletes who demand the best. Futuristic performance meets cutting-edge design.</p>
          </div>

          <div className="footer-col">
            <h4>Shop</h4>
            <Link to="/products">All Products</Link>
            <Link to="/products?sport=running">Running</Link>
            <Link to="/products?sport=basketball">Basketball</Link>
            <Link to="/products?sport=football">Football</Link>
          </div>

          <div className="footer-col">
            <h4>Account</h4>
            <Link to="/profile">Profile</Link>
            <Link to="/orders">Orders</Link>
            <Link to="/cart">Cart</Link>
          </div>

          <div className="footer-col">
            <h4>Company</h4>
            <a href="#">About Us</a>
            <a href="#">Contact</a>
            <a href="#">Careers</a>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} APEX Sports. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

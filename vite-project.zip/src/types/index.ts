export interface User {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: "customer" | "admin";
  createdAt: Date;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  compareAtPrice?: number;
  images: string[];
  category: string;
  sport: string;
  brand: string;
  stock: number;
  rating: number;
  reviewCount: number;
  featured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProductVariant {
  id: string;
  productId: string;
  size?: string;
  color?: string;
  stock: number;
  price: number;
}

export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
  variant?: ProductVariant;
}

export interface Order {
  id: string;
  userId: string;
  items: OrderItem[];
  total: number;
  status: "pending" | "processing" | "completed" | "cancelled";
  shippingAddress: Address;
  createdAt: Date;
  updatedAt: Date;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  price: number;
  quantity: number;
  variant?: string;
}

export interface Address {
  fullName: string;
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  productId: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image?: string;
}

export interface Sport {
  id: string;
  name: string;
  slug: string;
  icon?: string;
  image?: string;
}

export interface InventoryLog {
  id: string;
  productId: string;
  type: "sale" | "restock" | "manual";
  quantity: number;
  note?: string;
  createdAt: Date;
}

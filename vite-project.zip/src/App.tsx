﻿import { Routes, Route } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import Navbar from "./components/Navbar/Navbar";
import Footer from "./components/Footer/Footer";
import ProtectedRoute from "./components/ProtectedRoute";
import Home from "./pages/Home/Home";
import { LoginPage, RegisterPage } from "./pages/Auth/Auth";
import ProductsPage from "./pages/Products/Products";
import ProductDetail from "./pages/Products/ProductDetail";
import CartPage from "./pages/Cart/Cart";
import CheckoutPage from "./pages/Checkout/Checkout";
import OrdersPage from "./pages/Orders/Orders";
import ProfilePage from "./pages/Profile/Profile";
import {
  AdminLayout,
  AdminDashboard,
  AdminProducts,
  AdminOrders,
  AdminInventory,
  AdminCategories,
  AdminReviews,
} from "./pages/Admin/Admin";

export default function App() {
  return (
    <>
      <div className="bg-grid" />
      <div className="bg-orb bg-orb-1" />
      <div className="bg-orb bg-orb-2" />
      <div className="bg-orb bg-orb-3" />

      <Navbar />

      <AnimatePresence mode="wait">
        <Routes>
          <Route path="/" element={<><Home /><Footer /></>} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/products" element={<><ProductsPage /><Footer /></>} />
          <Route path="/products/:id" element={<><ProductDetail /><Footer /></>} />
          <Route path="/cart" element={<><CartPage /><Footer /></>} />
          <Route
            path="/checkout"
            element={
              <ProtectedRoute>
                <CheckoutPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/orders"
            element={
              <ProtectedRoute>
                <><OrdersPage /><Footer /></>
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <ProfilePage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin"
            element={
              <ProtectedRoute adminOnly>
                <AdminLayout />
              </ProtectedRoute>
            }
          >
            <Route index element={<AdminDashboard />} />
            <Route path="products" element={<AdminProducts />} />
            <Route path="orders" element={<AdminOrders />} />
            <Route path="inventory" element={<AdminInventory />} />
            <Route path="categories" element={<AdminCategories />} />
            <Route path="reviews" element={<AdminReviews />} />
          </Route>
        </Routes>
      </AnimatePresence>
    </>
  );
}

/**
 * Seed Firestore with mock data for the APEX Sporting Goods store.
 * Run: node scripts/seed.mjs
 */

import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, Timestamp } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDaoMftrXKlEgI2iNG6f6_hA67hEoDUMAA",
  authDomain: "sporting-goods-30f8b.firebaseapp.com",
  projectId: "sporting-goods-30f8b",
  storageBucket: "sporting-goods-30f8b.firebasestorage.app",
  messagingSenderId: "793307101380",
  appId: "1:793307101380:web:2e8c97fb9f39c1fd61b191",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const now = Timestamp.now();

/* ───────── Products ───────── */
const products = [
  // Running
  {
    name: "Air Zoom Pegasus 41",
    description: "Responsive cushioning and a breathable upper deliver a smooth, comfortable ride mile after mile.",
    price: 129.99,
    compareAtPrice: 159.99,
    images: ["https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600"],
    category: "shoes",
    sport: "running",
    brand: "Nike",
    stock: 50,
    rating: 4.7,
    reviewCount: 234,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Ultraboost 24",
    description: "Energy-returning BOOST midsole with a Primeknit upper for a locked-in, adaptive fit.",
    price: 189.99,
    images: ["https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=600"],
    category: "shoes",
    sport: "running",
    brand: "Adidas",
    stock: 35,
    rating: 4.8,
    reviewCount: 189,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Dri-FIT Running Tee",
    description: "Lightweight, sweat-wicking fabric keeps you dry and comfortable on every run.",
    price: 44.99,
    images: ["https://images.unsplash.com/photo-1581655353564-df123a1eb820?w=600"],
    category: "apparel",
    sport: "running",
    brand: "Nike",
    stock: 80,
    rating: 4.5,
    reviewCount: 312,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "GEL-Nimbus 26",
    description: "Pure comfort with FF BLAST PLUS cushioning for long-distance running sessions.",
    price: 159.99,
    compareAtPrice: 179.99,
    images: ["https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=600"],
    category: "shoes",
    sport: "running",
    brand: "ASICS",
    stock: 28,
    rating: 4.6,
    reviewCount: 156,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Running Hydration Vest",
    description: "Lightweight vest with 1.5L reservoir and multiple pockets for trail and ultra runs.",
    price: 79.99,
    images: ["https://images.unsplash.com/photo-1571008887538-b36bb32f4571?w=600"],
    category: "accessories",
    sport: "running",
    brand: "Salomon",
    stock: 22,
    rating: 4.4,
    reviewCount: 87,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },

  // Basketball
  {
    name: "Curry 11",
    description: "Lightweight, responsive shoe with UA Flow cushioning for explosive movements on the court.",
    price: 159.99,
    images: ["https://images.unsplash.com/photo-1579338559194-a162d19bf842?w=600"],
    category: "shoes",
    sport: "basketball",
    brand: "Under Armour",
    stock: 25,
    rating: 4.6,
    reviewCount: 156,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "KD 17",
    description: "Zoom Air cushioning with a midfoot strap for lockdown support during quick cuts.",
    price: 149.99,
    compareAtPrice: 169.99,
    images: ["https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=600"],
    category: "shoes",
    sport: "basketball",
    brand: "Nike",
    stock: 30,
    rating: 4.5,
    reviewCount: 98,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Evolution Game Basketball",
    description: "Indoor/outdoor composite leather basketball with deep channel design for superior grip.",
    price: 34.99,
    images: ["https://images.unsplash.com/photo-1519861531473-9200262188bf?w=600"],
    category: "equipment",
    sport: "basketball",
    brand: "Wilson",
    stock: 65,
    rating: 4.7,
    reviewCount: 421,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Pro Basketball Shorts",
    description: "Breathable, moisture-wicking shorts with 7-inch inseam and side pockets.",
    price: 54.99,
    images: ["https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=600"],
    category: "apparel",
    sport: "basketball",
    brand: "Nike",
    stock: 45,
    rating: 4.3,
    reviewCount: 178,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },

  // Football
  {
    name: "Predator Edge",
    description: "Striking precision with Demonskin 2.0 rubber elements for enhanced ball control.",
    price: 119.99,
    images: ["https://images.unsplash.com/photo-1511886929837-354d827aae26?w=600"],
    category: "shoes",
    sport: "football",
    brand: "Adidas",
    stock: 40,
    rating: 4.4,
    reviewCount: 203,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Phantom GX Elite",
    description: "NikeSkin upper provides a barefoot touch on the ball with precision-engineered grip zones.",
    price: 134.99,
    compareAtPrice: 159.99,
    images: ["https://images.unsplash.com/photo-1614632537197-38a17061c2bd?w=600"],
    category: "shoes",
    sport: "football",
    brand: "Nike",
    stock: 20,
    rating: 4.6,
    reviewCount: 145,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Premier League Match Ball",
    description: "Official match ball with Aerowsculpt technology for consistent flight at every speed.",
    price: 64.99,
    images: ["https://images.unsplash.com/photo-1575361204480-aadea25e6e68?w=600"],
    category: "equipment",
    sport: "football",
    brand: "Nike",
    stock: 55,
    rating: 4.8,
    reviewCount: 312,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Pro Goalkeeper Gloves",
    description: "Latex palm with 4mm cushioned foam for superior grip and shot absorption.",
    price: 89.99,
    images: ["https://images.unsplash.com/photo-1614632537423-1e6e6ce56fa6?w=600"],
    category: "accessories",
    sport: "football",
    brand: "Adidas",
    stock: 30,
    rating: 4.5,
    reviewCount: 95,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },

  // Tennis
  {
    name: "Pro Staff RF97 Autograph",
    description: "Roger Federer's racket of choice — braided graphite for precise control and feel.",
    price: 249.99,
    images: ["https://images.unsplash.com/photo-1622279457486-62dcc4a431d6?w=600"],
    category: "equipment",
    sport: "tennis",
    brand: "Wilson",
    stock: 15,
    rating: 4.9,
    reviewCount: 67,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Pure Aero 2024",
    description: "Spin-focused frame with aero beam technology for maximum rotation on every shot.",
    price: 229.99,
    images: ["https://images.unsplash.com/photo-1617883861744-13b534e1b850?w=600"],
    category: "equipment",
    sport: "tennis",
    brand: "Babolat",
    stock: 18,
    rating: 4.7,
    reviewCount: 89,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Court Vapor Pro Tennis Shoes",
    description: "Lightweight court shoe with herringbone outsole for grip on hard and clay courts.",
    price: 139.99,
    compareAtPrice: 159.99,
    images: ["https://images.unsplash.com/photo-1554068865-24cecd4e34b8?w=600"],
    category: "shoes",
    sport: "tennis",
    brand: "Nike",
    stock: 32,
    rating: 4.5,
    reviewCount: 123,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },

  // Swimming
  {
    name: "Fastskin LZR Pure Valor",
    description: "Competition swimsuit with bonded seams and water-repellent fabric for reduced drag.",
    price: 89.99,
    images: ["https://images.unsplash.com/photo-1530549387789-4c1017266635?w=600"],
    category: "apparel",
    sport: "swimming",
    brand: "Speedo",
    stock: 60,
    rating: 4.6,
    reviewCount: 176,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Swedish Competition Goggles",
    description: "Ultra-low profile racing goggles with anti-fog lenses and adjustable nose bridge.",
    price: 24.99,
    images: ["https://images.unsplash.com/photo-1551524164-687a55dd1126?w=600"],
    category: "accessories",
    sport: "swimming",
    brand: "Speedo",
    stock: 90,
    rating: 4.4,
    reviewCount: 265,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Training Kickboard",
    description: "EVA foam kickboard for building leg strength and refining kick technique.",
    price: 19.99,
    images: ["https://images.unsplash.com/photo-1560090995-01b52a1aae0c?w=600"],
    category: "equipment",
    sport: "swimming",
    brand: "TYR",
    stock: 75,
    rating: 4.2,
    reviewCount: 134,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },

  // Training / Gym
  {
    name: "Training Gloves Pro",
    description: "Full wrist-wrap support with ventilated mesh palm for heavy lifting sessions.",
    price: 34.99,
    images: ["https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=600"],
    category: "accessories",
    sport: "training",
    brand: "Nike",
    stock: 100,
    rating: 4.3,
    reviewCount: 287,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Compression Shorts",
    description: "HeatGear fabric wicks sweat and dries fast, keeping you cool under pressure.",
    price: 39.99,
    images: ["https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=600"],
    category: "apparel",
    sport: "training",
    brand: "Under Armour",
    stock: 70,
    rating: 4.4,
    reviewCount: 198,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Adjustable Dumbbell Set (5-50 lb)",
    description: "Space-saving adjustable dumbbells replacing 15 sets of weights. Quick-change mechanism.",
    price: 299.99,
    compareAtPrice: 399.99,
    images: ["https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?w=600"],
    category: "equipment",
    sport: "training",
    brand: "Bowflex",
    stock: 12,
    rating: 4.8,
    reviewCount: 542,
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Resistance Bands Set (5-Pack)",
    description: "Five progressive-resistance latex bands for warm-ups, rehab, and strength training.",
    price: 24.99,
    images: ["https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=600"],
    category: "accessories",
    sport: "training",
    brand: "TheraBand",
    stock: 150,
    rating: 4.5,
    reviewCount: 623,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
  {
    name: "Premium Yoga Mat",
    description: "6mm thick non-slip TPE mat with alignment lines. Eco-friendly and latex-free.",
    price: 49.99,
    images: ["https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=600"],
    category: "equipment",
    sport: "training",
    brand: "Manduka",
    stock: 40,
    rating: 4.6,
    reviewCount: 341,
    featured: false,
    createdAt: now,
    updatedAt: now,
  },
];

/* ───────── Categories ───────── */
const categories = [
  { name: "Shoes", slug: "shoes" },
  { name: "Apparel", slug: "apparel" },
  { name: "Equipment", slug: "equipment" },
  { name: "Accessories", slug: "accessories" },
];

/* ───────── Sports ───────── */
const sports = [
  { name: "Running", slug: "running", icon: "🏃" },
  { name: "Basketball", slug: "basketball", icon: "🏀" },
  { name: "Football", slug: "football", icon: "⚽" },
  { name: "Tennis", slug: "tennis", icon: "🎾" },
  { name: "Swimming", slug: "swimming", icon: "🏊" },
  { name: "Training", slug: "training", icon: "🏋️" },
];

/* ───────── Reviews (linked to products after creation) ───────── */
const reviewTemplates = [
  { rating: 5, comment: "Absolutely love this! Best purchase I've made all year.", userName: "Alex R." },
  { rating: 4, comment: "Great quality for the price. Would definitely recommend.", userName: "Jordan M." },
  { rating: 5, comment: "Perfect fit and amazing performance. Will buy again.", userName: "Sam K." },
  { rating: 4, comment: "Solid product. Shipping was fast too.", userName: "Taylor W." },
  { rating: 3, comment: "Decent quality but sizing runs a bit small.", userName: "Casey B." },
  { rating: 5, comment: "Top notch! Exceeded my expectations.", userName: "Morgan L." },
  { rating: 4, comment: "Very comfortable and durable. Happy with this purchase.", userName: "Riley J." },
  { rating: 5, comment: "Professional grade quality at an accessible price point.", userName: "Drew P." },
];

/* ───────── Seed Function ───────── */
async function seed() {
  console.log("🌱 Starting Firestore seed...\n");

  // Seed categories
  console.log("📁 Seeding categories...");
  for (const cat of categories) {
    await addDoc(collection(db, "categories"), cat);
  }
  console.log(`   ✓ ${categories.length} categories added`);

  // Seed sports
  console.log("🏅 Seeding sports...");
  for (const sport of sports) {
    await addDoc(collection(db, "sports"), sport);
  }
  console.log(`   ✓ ${sports.length} sports added`);

  // Seed products & reviews
  console.log("📦 Seeding products...");
  const productIds = [];
  for (const product of products) {
    const docRef = await addDoc(collection(db, "products"), product);
    productIds.push({ id: docRef.id, name: product.name });
  }
  console.log(`   ✓ ${products.length} products added`);

  // Seed reviews (2-3 reviews per product)
  console.log("⭐ Seeding reviews...");
  let reviewCount = 0;
  for (const { id: productId } of productIds) {
    const numReviews = 2 + Math.floor(Math.random() * 2); // 2 or 3
    for (let i = 0; i < numReviews; i++) {
      const template = reviewTemplates[Math.floor(Math.random() * reviewTemplates.length)];
      await addDoc(collection(db, "reviews"), {
        productId,
        userId: `mock-user-${Math.floor(Math.random() * 100)}`,
        userName: template.userName,
        rating: template.rating,
        comment: template.comment,
        createdAt: now,
      });
      reviewCount++;
    }
  }
  console.log(`   ✓ ${reviewCount} reviews added`);

  console.log("\n✅ Seed complete! Your Firestore database is populated.");
  console.log(`   Products: ${products.length}`);
  console.log(`   Categories: ${categories.length}`);
  console.log(`   Sports: ${sports.length}`);
  console.log(`   Reviews: ${reviewCount}`);
  process.exit(0);
}

seed().catch((err) => {
  console.error("❌ Seed failed:", err);
  process.exit(1);
});
